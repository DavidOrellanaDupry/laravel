@extends('layouts.app')
@section('content')

<div class="container" style="">
  <div class="row">
    <div class="col-12 text-center">
      <h1 class="">Literatura recomendada</h1>
    </div>
  </div></br>

  <div class="row">
    <div class="col-6 text-left" style="font-size: 40px;" >
      <img class="rounded-circle" src="http://2.bp.blogspot.com/-JKoLDG0MdhY/TuKs8GcNmQI/AAAAAAAAAiM/XQcKDLfQOWc/s200/Paul%2BWasher.jpeg" alt="">
      <a href="https://clcchile.com/search/products?SearchNodeId=113&sq=paul%20washer">Paul Washer</a>
    </div>
    <div class="col-6 text-left" style="font-size: 40px;  ">
      <img class="rounded-circle" src="http://2.bp.blogspot.com/-JKoLDG0MdhY/TuKs8GcNmQI/AAAAAAAAAiM/XQcKDLfQOWc/s200/Paul%2BWasher.jpeg" alt="">
      <a href="https://clcchile.com/search/products?SearchNodeId=113&sq=paul%20washer">Paul Washer</a>
    </div>
  </div></br>
  <div class="row">
    <div class="col-6 text-left" style="font-size: 40px;  ">
      <img class="rounded-circle" src="http://2.bp.blogspot.com/-JKoLDG0MdhY/TuKs8GcNmQI/AAAAAAAAAiM/XQcKDLfQOWc/s200/Paul%2BWasher.jpeg" alt="">
      <a href="https://clcchile.com/search/products?SearchNodeId=113&sq=paul%20washer">Paul Washer</a>
    </div>
    <div class="col-6 text-left" style="font-size: 40px;  ">
      <img class="rounded-circle" src="http://2.bp.blogspot.com/-JKoLDG0MdhY/TuKs8GcNmQI/AAAAAAAAAiM/XQcKDLfQOWc/s200/Paul%2BWasher.jpeg" alt="">
      <a href="https://clcchile.com/search/products?SearchNodeId=113&sq=paul%20washer">Paul Washer</a>
    </div>
  </div></br>
  <div class="row">
    <div class="col-6 text-left" style="font-size: 40px;  ">
      <img class="rounded-circle" src="http://2.bp.blogspot.com/-JKoLDG0MdhY/TuKs8GcNmQI/AAAAAAAAAiM/XQcKDLfQOWc/s200/Paul%2BWasher.jpeg" alt="">
      <a href="https://clcchile.com/search/products?SearchNodeId=113&sq=paul%20washer">Paul Washer</a>
    </div>
    <div class="col-6 text-left" style="font-size: 40px;  ">
      <img class="rounded-circle" src="http://2.bp.blogspot.com/-JKoLDG0MdhY/TuKs8GcNmQI/AAAAAAAAAiM/XQcKDLfQOWc/s200/Paul%2BWasher.jpeg" alt="">
      <a href="https://clcchile.com/search/products?SearchNodeId=113&sq=paul%20washer">Paul Washer</a>
    </div>
  </div></br>
</div>
<img src=" " alt="">


@endsection
