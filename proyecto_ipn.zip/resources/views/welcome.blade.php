@extends('layouts.app')
@section('content')

<body>
<div class="container">
  <div class="title m-b-md">
  <h1 align="center">"CORPORACION IPN"</h1>
  </div>
  </br>
  </br>
  </br>
  </br>
  </br>
  </br>

  <div class="row align-center">
  </br>


  <img src="http://iglesiaelmonte.weebly.com/uploads/5/1/7/3/51736543/465607.png" class="rounded mx-auto d-block" alt="">

</div>

  </div>
  <div class="row">

  </div>
</div>



</body>

@endsection
