<?php echo e($slot); ?>

<?php /**PATH C:\Users\David\Desktop\proyectos-david\proyecto_ipn\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>