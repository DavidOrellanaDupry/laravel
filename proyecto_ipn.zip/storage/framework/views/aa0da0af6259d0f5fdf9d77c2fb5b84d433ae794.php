<?php $__env->startSection('content'); ?>

<body>
<div class="container">
  <div class="title m-b-md">
  <h1 align="center">"CORPORACION IPN"</h1>
  </div>
  </br>
  </br>
  </br>
  </br>
  </br>
  </br>

  <div class="row align-center">
  </br>


  <img src="http://iglesiaelmonte.weebly.com/uploads/5/1/7/3/51736543/465607.png" class="rounded mx-auto d-block" alt="">

</div>

  </div>
  <div class="row">

  </div>
</div>



</body>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\David\Desktop\proyectos-david\proyecto_ipn\resources\views/welcome.blade.php ENDPATH**/ ?>